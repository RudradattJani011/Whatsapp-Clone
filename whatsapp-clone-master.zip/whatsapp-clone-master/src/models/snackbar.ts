export interface Snackbar {
  showing: boolean;
  text: string;
  color: string;
}
