export interface Chat {
  id: number;
  message: string;
  date: string;
  time: string;
  timestamp: number;
  senderId: string;
}
